#include <iostream>
#include <cstdio>
#include <string>

using namespace std;

int main() {
    int N; 
    scanf("%d\n", &N);
    while (N--) {
        string aux, renglon;
        aux.clear();
        //La primera linea se omite
        getline(cin, aux);
        //Se inicializa la cadena donde se desencriptara
        string texto(aux.length()-2, '\0');
        //i son las columnas o la iesima posicion del binario
        for (int i = 1; i < 10; i++) {
            renglon.clear();
            getline(cin, renglon);
            if(i==9)continue;
            for(int j=1; j<renglon.length()-1; j++) {
                //Se suma en dado caso en el j-1 caracter el binario dado por la fila
                if(renglon[j]=='\\')texto[j-1]+=1<<(i-1);
            }
        }
        //Se omite la ultima linea
        if (N>0){getline(cin, aux);}
        cout<<texto<<endl;
    }
}