#include <iostream>

using namespace std;

#define MAX 2147483647

long long DP[205];//DP[i], guardará la maxima suma para la cadena de caracteres S[i,...,end]

long long maximaSuma(int i, string S, int N){
    if (i==N) return 0;
    
    long long maxSuma = DP[i];
    if (maxSuma==-1){
        maxSuma=0;
        int sig=i+1;
        long long amount = S[i]-'0';
        while (amount <= MAX && sig <= N){//para que sea un entero de 32 bits
            //Recursividad
            maxSuma = max(amount + maximaSuma(sig, S, N), maxSuma);
            amount = amount*10 + S[sig]-'0';
            ++sig;
        }
        DP[i]=maxSuma;
    }
    return maxSuma;
}

int main(){
    int casos;
    string S;
    int N;
    cin >> casos;
    while (casos--){
        cin >> S;
        N = S.size();
        S.push_back('.');
        for (int i = 0; i < N; ++i){
            DP[i]=-1;
        }
        cout<<maximaSuma(0, S, N)<<endl;
    }
}