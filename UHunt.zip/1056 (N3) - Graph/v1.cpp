#include <iostream>
#include <map>

using namespace std;

#define M 51
#define NO_CNX M*M+100

int adjace[M][M];//matriz de adjacencia. 0 conectado, -1 desconectado

int MaxConexion(int P){
    for (int k=0; k<P; k++) {
        for (int i=0; i<P; i++) {
            for (int j=0; j<P; j++) {
                adjace[i][j] = min(adjace[i][j], adjace[i][k] + adjace[k][j]);
            }
        }
    }

    int m = 0;
    for (int i=0; i<P; i++) {
        for (int j=0; j<P; j++) {
            if (adjace[i][j]==NO_CNX) {
                m = -1;
                i = P;
                break;
            }
            m = max(m, adjace[i][j]);
        }
    }
    return m;
}

int main(){
    int P, R, caso, id;
    
    string a, b;
    map<string,int> dir;//contendra a las personas de la red
    caso=0;
    scanf("%d %d", &P, &R);
    while (P!=0 || R!=0) {
        caso++;
        dir.clear();
        for (int i=0; i<P; i++) {
            for (int j=0; j<P; j++) {
                if (i==j) {
                    adjace[i][j] = 0;//contectado consigo mismo
                    continue;
                }
                adjace[i][j] = NO_CNX;//desconectado
            }
        }

        //Se registran las personas
        id = 0;
        while (R--) {
            cin >> a >> b;
            if (dir.find(a) == dir.end()) {
                dir[a] = id;
                id++;
            }
            if (dir.find(b) == dir.end()) {
                dir[b] = id;
                id++;
            }
            //se conectan
            adjace[dir[a]][dir[b]] = 1;
            adjace[dir[b]][dir[a]] = 1;
        }
 
        int m=MaxConexion(P);
        if(m==-1){
            printf("Network %d: DISCONNECTED\n", caso);
        }else{
            printf("Network %d: %d\n", caso, m);
        }
        printf("\n");
        
        scanf("%d %d", &P, &R);
    }
 
    return 0;
}