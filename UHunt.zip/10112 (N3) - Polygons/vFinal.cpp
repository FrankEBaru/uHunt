#include <iostream>
#include <cmath>

using namespace std; 

# define M_PI           3.14159265358979323846  /* pi */

//FUNCIONES PARA VECTORES
class vect{
    public:
    int x, y;
    friend vect operator - (vect const &, vect const &);
    bool operator == (const vect &v){
        if(x==v.x && y==v.y)return true;
        return false;
    }
};
vect operator - (vect const &u, vect const &v){
    vect r;
    r.x=u.x-v.x;
    r.y=u.y-v.y;
    return r;
}
int dot(vect u, vect v){
    return u.x*v.x + u.y*v.y;
}
vect ortogonal(vect u){//devuelbe el rotado 90 encontra del reloj
    vect r;
    r.x=-u.y;
    r.y=u.x;
    return r;
}

//FUNCIONES PARA TRIANGULOS
struct triangulo{
    vect A;
    vect B;
    vect C;
    double area(){
        double r= 0.5 * ( (C.y-A.y)*(B.x-A.x) - (B.y-A.y)*(C.x-A.x) );
        return fabs(r);
    }
};

int signo(int a){
    if(a<0)return -1;
    if(a==0)return 0;
    return 1;
}

bool isInside(triangulo T, vect p){
    //Si p es alguno de los vertices
    if(T.A==p || T.B==p || T.C==p)return true;
    //Calcular en que semiplanos esta p respecto a los lados de T
    int a=signo( dot( ortogonal(T.B-T.A), p-T.A) );
    int b=signo( dot( ortogonal(T.C-T.B), p-T.B) );
    int c=signo( dot( ortogonal(T.A-T.C), p-T.C) );

    //Si esta en algun lado
    if(a==0 && b==c)return true;
    if(b==0 && a==c)return true;
    if(c==0 && a==b)return true;

    //Si estan en las mismas direcciones
    if(a==1 && b==1 && c==1)return true;
    if(a==-1 && b==-1 && c==-1)return true;

    //De lo contrario se encuentra afuera del triangulo
    return false;
}

void maxT(vect arr[], int n){
    int m1, m2, m3;
    double mArea=0;
    double Areaaux;
    bool adentro;
    triangulo T;
    for(int i=0; i<=n-3; i++){
        for(int j=i+1; j<=n-2; j++){
            for(int k=j+1; k<=n-1; k++){
                T.A=arr[i];T.B=arr[j];T.C=arr[k];
                //Se checa si algun punto esta dentro de T
                adentro=false;
                for(int l=0; l<n; l++){
                    if(l==i || l==j || l==k )continue;
                    if(isInside(T, arr[l])){
                        adentro=true;
                        break;
                    }
                }
                //Si no hay punto adentro calcular area y ver si es maxima
                if(!adentro){
                    Areaaux=T.area();
                    if(mArea<Areaaux){
                        mArea=Areaaux;
                        m1=i;
                        m2=j;
                        m3=k;
                    }
                }
            }
        }
    }
    char t1, t2, t3;
    t1=65+m1;
    t2=65+m2;
    t3=65+m3;
    cout<<t1<<t2<<t3<<endl;
}


int main(){
    vect arr[20];
    triangulo T;
    int n, x, y;
    char a;
    scanf("%d", &n);
    while(n!=0){
        for(int i=0; i<n; i++){
            cin>>a;
            scanf("%d", &arr[i].x);
            scanf("%d", &arr[i].y);
        }
        maxT(arr, n);
        scanf("%d", &n);
    }
    //cout<<"fin"<<endl;
    return 0;
}