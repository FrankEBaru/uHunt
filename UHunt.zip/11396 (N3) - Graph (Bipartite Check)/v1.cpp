#include <iostream>
#include <vector>
#include <queue>

using namespace std;

vector<int>aristas[1000];//Guardara las aristas que conectan nodos

bool esBipartita(int s, int V){
    int color[1000];//Coloracion para verificar si es bipartita
    int visitados[1000];//Auxiliar para nodos ya visitados
    queue<int>cola;//auxiliar en nodos por visitar

    //Se inicializa 
    for(int i=1;i<=V;i++){
        visitados[i]=0;
        color[i]=-1;
    }
    cola.push(s);
    color[s]=1;
    visitados[s]=1;

    while(!cola.empty()){
        int nactual=cola.front();
        for(int k=0; k<aristas[nactual].size(); k++){
            //Si no ha sido visitado y no tiene color
            if(visitados[aristas[nactual][k]]==0 && color[aristas[nactual][k]]==-1){
                 cola.push(aristas[nactual][k]);//se agraga a la cola para visitar
                 visitados[aristas[nactual][k]]=1;//Se marca como visitado
                 color[aristas[nactual][k]]=1-color[nactual];//sera del otro color distinto a nactual
            }
        }
        for(int k=0; k<aristas[nactual].size(); k++){
            if(visitados[aristas[nactual][k]]==1 && color[aristas[nactual][k]]==color[nactual]){
                return false;
            }
        }
        cola.pop();
    }
    return true;
}


int main(){
    int V, a, b;
    scanf("%d", &V);
    while(V!=0){
        for(int i=0; i<V+1; i++){
            aristas[i].clear();
        }
        scanf("%d %d", &a, &b);
        while(a!=0 || b!=0){
            aristas[a].push_back(b);
            aristas[b].push_back(a);
            scanf("%d %d", &a, &b);
        }
        if(esBipartita(1, V)){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
        scanf("%d", &V);
    }
    return 0;
}