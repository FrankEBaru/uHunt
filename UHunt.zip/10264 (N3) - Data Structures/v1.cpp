#include <iostream>
#include <cmath>
using namespace std;

#define MAXDIM 15

void calcPoder(int peso[], int poder[], int N, int npuntos){
    bool bit;
    for(int i=0; i<npuntos; i++){
        poder[i]=0;
        for(int j=0; j<N; j++){
            bit = (i & (1<<j));//da el valor del j-esimo bit (de derecha a izq) del entero i
            if(bit==1){
                //Al poder de la esquina i se le agrega el peso de uno de sus N vecinos
                poder[i]+=peso[i-(int)pow(2,j)];
            }else if(bit==0){
                //Al poder de la esquina i se le agrega el peso de uno de sus N vecinos
                poder[i]+=peso[i+(int)pow(2,j)];
            }
        }
    }
}

int maxSum(int poder[], int N, int npuntos){
    int maxima=0;
    bool bit;
    int sumparcial;
    for(int i=0; i<npuntos; i++){
        for(int j=0; j<N; j++){
            bit = (i & (1<<j));//da el valor del j-esimo bit (de derecha a izq) del entero i
            if(bit==1){
                //Al poder de la esquina i se le agrega el peso de uno de sus N vecinos
                sumparcial=poder[i]+poder[i-(int)pow(2,j)];
            }else if(bit==0){
                //Al poder de la esquina i se le agrega el peso de uno de sus N vecinos
                sumparcial=poder[i]+poder[i+(int)pow(2,j)];
            }
            if(sumparcial>maxima)maxima=sumparcial;
        }
    }
    return maxima;
    //printf("%d\n",maxima);
}

int main(){
    int peso[(int)pow(2,MAXDIM)+1];
    int poder[(int)pow(2,MAXDIM)+1];
    int N;
    int numlinesread=0;
    while(cin>>N){
        int npuntos=pow(2,N);
        numlinesread+=npuntos+1;
        for(int i=0; i<npuntos; i++){
            scanf("%d", &peso[i]);
        }
        calcPoder(peso, poder, N, npuntos);
        cout<<maxSum(poder, N, npuntos)<<endl;
        //for(int i=0; i<npuntos; i++)cout<<poder[i]<<endl;
    }

    return 0;
}
