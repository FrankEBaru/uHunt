#include <iostream>
#include <string>
#include <sstream>
#include <cctype>

using namespace std;

int rom[8]={1,5,10,50,100,500,1000, 5000};
char romC[7]={'I','V','X','L','C','D','M'};

string s;

void printRomano(int n){
    int inf=0;
    int resto;
    for(int i=0; i<7; i++){
        if(rom[i]<=n && n<rom[i+1]){inf=i;break;}
    }
    //Si sera resta caso 1
    if( (inf%2==0) && (4*rom[inf]<=n) && n!=4000 ){//////!!!!!!! CHECAR EL CASO DE 3000 Y 3999
        //printf("%c%c",romC[inf],romC[inf+1]);
        s.push_back(romC[inf]);
        s.push_back(romC[inf+1]);
        resto=n-(rom[inf+1]-rom[inf]);
        if(resto==0){
            //printf("\n");
            return;
        }else{
            printRomano(resto);
        }
    }
    //Si se resta caso 2
    else if( rom[inf+1]-rom[inf-1]<=n ){
        //printf("%c%c",romC[inf-1],romC[inf+1]);
        s.push_back(romC[inf-1]);
        s.push_back(romC[inf+1]);
        resto=n-(rom[inf+1]-rom[inf-1]);
        if(resto==0){
            //printf("\n");
            return;
        }else{
            printRomano(resto);
        }
    }
    //Si sera suma
    else{
        //printf("%c",romC[inf]);
        s.push_back(romC[inf]);
        resto=n-rom[inf];
        if(resto==0){
            //printf("\n");
            return;
        }else{
            printRomano(resto);
        }
    }
    return;
}

int num(char r){
    if(r=='I')return 1;
    if(r=='V' || r=='X' || r=='L' || r=='C')return 2;
    if(r=='D')return 3;
    return 4;
}

int matches(int n){
    s.clear();
    printRomano(n);
    int number=0;
    for(int i=0; i<s.length(); i++){
        number+=num(s[i]);
    }
    return number;
}

int main(){
    int n;
    while(cin>>n){
        //s.clear();
        printf("%d\n", matches(n));
    }
    return 0;
}