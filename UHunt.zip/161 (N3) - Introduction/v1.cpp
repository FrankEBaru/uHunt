#include <iostream>
#include <vector>

using namespace std;

#define MAX_TIEMPO 18000 //5 horas

void printHora(int tiempo){
    int horas = tiempo / 3600;
    int minutos = (tiempo - horas*3600)/60;
    int segundos = (tiempo - horas*3600 - minutos*60);
    printf("0%d:%02d:%02d\n", horas, minutos, segundos);
}

// La idea: para cada posible tiempo, se verificara si 
// para cada semaforo, este tiempo estaria en verde o no
// si esta en verde encontramos el tiempo que queremos 
// por que se busca linealmente desde el minimo tiempo hasta
// las 5 horas
void minimo(vector <int> tiempos, int minTiempo){
    int tiempoActual=2*minTiempo;
    bool esCorrecto;
    while(tiempoActual<=MAX_TIEMPO){
        esCorrecto=false;
        //Se verifica que este en verde e cada semaforo
        for(int i=0; i<tiempos.size(); i++){
            //Si no esta en verde el i esimo semaforo
            if( tiempos[i]-5 <= tiempoActual % (2*tiempos[i]) ){
                tiempoActual++;
                esCorrecto=false;
                break;
            }
            esCorrecto=true;
        }
        if(esCorrecto){
            printHora(tiempoActual);
            return;
        }else{
            tiempoActual++;
        }
    }
    cout<<"Signals fail to synchronise in 5 hours\n";
}


int main(){
    int tiempo1;
    int tiempoSig;
    int mintiempo;
    vector <int> tiempos;

    cin>>tiempo1;
    while(tiempo1!=0){
        mintiempo=tiempo1;
        tiempos.clear();
        tiempos.push_back(tiempo1);

        cin>>tiempoSig;
        while(tiempoSig!=0){ 
            if(tiempoSig<mintiempo)mintiempo=tiempoSig;
            tiempos.push_back(tiempoSig);
            cin>>tiempoSig;
        }
        /*RESPUESTA*/
        minimo(tiempos, mintiempo);

        cin>>tiempo1;
    }

    return 0;
}