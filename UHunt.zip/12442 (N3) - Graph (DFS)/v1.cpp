#include <iostream>

using namespace std;

#define MAXM 50002
int email[MAXM];//guardara G[i]=j es que i le manda correo a j
int visitado[MAXM];//auxiliar para marcar marcianos visitados al hacer DFS
int grado[MAXM];//Guardara la maxima cantidad de marcianos a los que llegaria el correo comenzando en i
 
int DFS(int u){
    int v, grad;
    v=email[u];
    grad=0;
    visitado[u]=1;
    if(!visitado[v])grad = DFS(v) + 1;
    visitado[u]=0;
    grado[u] = grad;
    return grad;
}
 
int main(){
    int C, N, u, v;
    int maximo, maxMarciano;
    scanf("%d",&C);
    for(int i=1; i<=C; i++){
        scanf("%d", &N);
        for(int k=1; k<=N; k++){
            scanf("%d %d",&u,&v);
            email[u]=v;
            visitado[u]=0;
            grado[u]=-1;
        }
        maximo=-1;
        maxMarciano=-1;
        for(int k=1; k<=N; k++){
            if(grado[k]==-1)DFS(k);
            if(grado[k]>maximo){maximo=grado[k];maxMarciano=k;}
        }
        printf("Case %d: %d\n",i,maxMarciano);
    }
    return 0;
}