#include <iostream>
#include <string>
#include <cmath>

using namespace std;

#define optimizar_io ios_base::sync_with_stdio(0);cin.tie(0);

int minimo(int numero){
    int anterior=numero;
    int siguiente=log10(numero)+1;
    int i=2;
    while(anterior!=siguiente){
        anterior=siguiente;
        siguiente=log10(siguiente)+1;
        i++;
    }
    return i;
}

int main(){
    optimizar_io;
    string numero;
    cin>>numero;
    while(numero!="END"){
        if(numero=="1"){
            printf("1\n");
        }else{
            printf("%d\n",minimo(numero.length()));
        }
        cin>>numero;
    }
    return 0;
}