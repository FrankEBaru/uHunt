#include <iostream>
#include <algorithm>

using namespace std;

struct punto{
    int row, col, valor;
};

void printPuntos(punto puntos[], int npuntos){
    for(int i=0; i<npuntos; i++){
        printf("row: %d col: %d val: %d\n", puntos[i].row, puntos[i].col, puntos[i].valor);
    }
}

void transpose(punto puntos[], int npuntos){
    for(int i=0; i<npuntos; i++){
        swap(puntos[i].col, puntos[i].row);
    }
}

//Esta funcion devuelve si a es menor que b; no hay puntos iguales
bool sortByrow(punto a, punto b){
    if(a.row==b.row){
        return (a.col < b.col);
    }else{
        return (a.row < b.row);
    }
}

void printSparce(punto puntos[], int npuntos, int nrows){
    sort(puntos, puntos+npuntos, sortByrow);
    int l=0, r=0;
    for(int curRow=1; curRow<=nrows; curRow++){
        if(puntos[l].row!=curRow){
            printf("0\n\n");
            continue;
        }
        while( puntos[l].row==puntos[r].row && r<=npuntos){r++;}
        printf("%d", r-l);
        for(int i=l; i<r; i++){
            printf(" %d", puntos[i].col);
        }
        printf("\n");
        for(int i=l; i<r-1; i++){
            printf("%d ", puntos[i].valor);
        }
        printf("%d\n", puntos[r-1].valor);
        l=r;
    }
}

int main(){
    //set
    punto puntos[1001];
    int npuntos;
    int nrow, ncol;
    //auxiliars
    int aux[2002];
    int p;
    while(cin>>nrow>>ncol){
        npuntos=0;
        for(int r=0; r<nrow; r++){
            cin>>p;
            for(int i=1; i<=2*p; i++){
                cin>>aux[i-1];
            }
            for(int i=0; i<p; i++){
                puntos[npuntos].row=r+1;
                puntos[npuntos].col=aux[i];
                puntos[npuntos].valor=aux[i+p];
                npuntos++;
            }
        }
        transpose(puntos, npuntos);
        printf("%d %d\n", ncol, nrow);
        printSparce(puntos, npuntos, ncol);
    }
    return 0;
}