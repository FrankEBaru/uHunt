#include <bitset>
#include <iostream>
#include <vector>
using namespace std;

#define SIZE 32100

bitset<SIZE+1> bs; // criba de primos, 1 si es primo, 0 si no
short int numeroPrimo[SIZE+1];
vector<int> primes; // contendra los primos

vector<int> diferencias; //Contendra la distancia entre primos consecutivos

void sieve()
{
    bs.set(); // todos los numeros a 1
    bs[0] = bs[1] = 0; // excepto 0 y 1
    
    
    numeroPrimo[0]=numeroPrimo[1]=0;
    int primoaanterior=0;
    int nprimo=0;
    for (int i = 2; i <=SIZE; i++)
    {
        numeroPrimo[i]=nprimo;
        if (bs[i])//si i es primo
        {
            nprimo++;
            //Se guarda el primo
            primes.push_back(i);
            //sus multiplos no son primos
            for (int j = i * i; j <= SIZE; j += i)
            {
                bs[j] = 0;
            }
            //Se registra la diferencia con el anterior si existe
            if(primoaanterior!=0){
                diferencias.push_back(i-primoaanterior);
                
            }
            primoaanterior=i;
        }
    }
}

void secuenciasU(int x, int y){
    int l=numeroPrimo[x];
    int r;
    if(bs[y]){
        r=numeroPrimo[y];
    }else{
        r=numeroPrimo[y]-1;
    }

    int aux=diferencias[l];
    int ini=l;
    for(int fin=l; fin<=r; fin++){

        if(aux!=diferencias[fin]){
            if(fin-ini>1){//Si encontro secuencias de primos unidistancia
                if(ini==l && l>0){//Si la secuencia esta al inicio del intervalo
                    if(diferencias[l-1]!=aux){
                        for(int i=ini; i<fin; i++){
                            printf("%d ", primes[i]);
                        }
                        printf("%d\n", primes[fin]);
                    }
                }else{
                    for(int i=ini; i<fin; i++){
                        printf("%d ", primes[i]);
                    }
                    printf("%d\n", primes[fin]);
                }
            }
            ini=fin;
            aux=diferencias[ini];
        }
        /*else if(fin==r && r+1<primes.size()){
            if(diferencias[r+1]!=aux){
                for(int i=ini; i<fin; i++){
                    printf("%d ", primes[i]);
                }
                printf("%d\n", primes[fin]);
            }
        }*/
    }
}


int main(){
    sieve();
    int x,y;
    scanf("%d", &x);
    scanf("%d", &y);
    while(x!=0 || y!=0){
        if(y<x)swap(x,y);
        secuenciasU(x,y);
        scanf("%d", &x);
        scanf("%d", &y);
    }
}