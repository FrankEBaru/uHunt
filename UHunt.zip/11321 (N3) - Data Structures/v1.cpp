#include <iostream>
#include <algorithm>

using namespace std;

int M=1;

//Esta funcion responde si a es menor a b
bool myOrder(int a, int b){
    int ma=a%M;
    int mb=b%M;
    if(ma==mb){
        int a2=abs(a%2);
        int b2=abs(b%2);
        if(a2==1 && b2==0)return true;
        if(a2==0 && b2==1)return false;
        if(a2==1 && b2==1)return (b<a);
        if(a2==0 && b2==0)return (a<b);
    }else{
        return (ma<mb);
    }
}

void imprimeOrden(int arr[], int N){
    sort(arr, arr+N, myOrder);
    for(int i=0; i<N; i++){
        printf("%d\n", arr[i]);
    }
}

int main(){
    int N;
    int arr[10001];
    cin>>N>>M;
    while(N!=0 &&  M!=0){
        for(int i=0; i<N; i++){
            scanf("%d", &arr[i]);
        }
        printf("%d %d\n", N, M);
        imprimeOrden(arr, N);
        cin>>N>>M;
    }
    printf("0 0\n");
    return 0;
}