#include <iostream>

using namespace std;

int main(){
    //input
    int X, R, C, M, N;
    int letra[26];
    char aux;
    //work
    int numMaximos=0;
    int maxFrec=0;
    scanf("%d", &X);
    for(int i=1; i<=X; i++){
        //Inicializar
        numMaximos=1;
        maxFrec=0;
        for(int j=0; j<26; j++)letra[j]=0;
        //Leer y calcular
        scanf("%d %d %d %d", &R, &C, &M, &N, &aux);//Se lee el char nueva linea para que no afecte luego
        for(int j=0; j<R*C; j++){
            //leer
            scanf(" %c", &aux);
            letra[aux-'A']++;
            //calcular
            if(letra[aux-'A']==maxFrec)numMaximos++;
            else if(letra[aux-'A']>maxFrec){numMaximos=1;maxFrec=letra[aux-'A'];}
        }
        printf("Case %d: %d\n", i, M*(numMaximos*maxFrec) + N*(R*C-numMaximos*maxFrec));
    }
    return 0;
}