#include <iostream>
#include <string>

using namespace std;

#define MAX 2000


int DP[MAX][MAX];
string s;

int calcularDP(int i, int j){
    //Se supone i<j
    if(DP[i][j]!=-1)return DP[i][j];//Si ya se calculo
    
    //CASO BASE
    if(i==j){//Si solo es un caracter
        DP[i][j]=0;
        return DP[i][j];
    }
    /*
    if(i+1==j){//Si solo son 2 caracteres y ya es palindromo
        if(s[i]==s[j]){DP[i][j]=0;return DP[i][j];}
        DP[i][j]=1;
        return DP[i][j];
    }
    */

    if(s[i]!=s[j]){//Si en estas posiciones no son iguales se debe caual de las 3 oeracioens es mejor
        //en caso se reemplaza s[i] con s[j] o viceversa (acdb --> dcdb ó acdb --> acda)
        int a=calcularDP(i+1, j-1)+1;
        //en caso se agregue s[i] despues de s[j] (acdb --> acdba)
        //ó en caso borre s[i] (acdb --> cdb) 
        int b=calcularDP(i+1, j)+1;
        //en caso ase agregue s[j] antes de s[i] (acdb --> dacbd)
        //ó en caso se borre s[j] (acdb --> acd)
        int c=calcularDP(i, j-1)+1;
        DP[i][j]=min(a, min(b,c));
        return DP[i][j];
    }

    //Si si es match y ademas no ha pasado lo anterior
    DP[i][j]=calcularDP(i+1, j-1);
    return DP[i][j];
}


int main(){
    int T;
    //string s;
    scanf("%d", &T);
    //cin>>T;
    for(int i=1; i<=T; i++){
        cin>>s;
        for(int j=0; j<s.length(); j++){
            for(int k=0; k<s.length(); k++){
                DP[j][k]=-1;
            }
        }
        calcularDP(0, s.length()-1);
        printf("Case %d: %d\n",i,DP[0][s.length()-1]);
    }
    return 0;
}

